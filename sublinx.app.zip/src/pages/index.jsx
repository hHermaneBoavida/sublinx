import Layout from "./Layout.jsx";

import Mapa from "./Mapa";

import BemVindo from "./BemVindo";

import Perfil from "./Perfil";

import Notificacoes from "./Notificacoes";

import Planos from "./Planos";

import CriarEvento from "./CriarEvento";

import MeusEventos from "./MeusEventos";

import ComprarIngresso from "./ComprarIngresso";

import Configuracoes from "./Configuracoes";

import Comunidade from "./Comunidade";

import Chat from "./Chat";

import Feed from "./Feed";

import Documentacao from "./Documentacao";

import Descobrir from "./Descobrir";

import ListaEspera from "./ListaEspera";

import Onboarding from "./Onboarding";

import ConfiguracoesPrivacidade from "./ConfiguracoesPrivacidade";

import EditarEvento from "./EditarEvento";

import DashboardOrganizador from "./DashboardOrganizador";

import Recompensas from "./Recompensas";

import Ranking from "./Ranking";

import HistoricoPontos from "./HistoricoPontos";

import EventoAoVivo from "./EventoAoVivo";

import IntegracoesIngressos from "./IntegracoesIngressos";

import PerfilUsuario from "./PerfilUsuario";

import Recomendacoes from "./Recomendacoes";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Mapa: Mapa,
    
    BemVindo: BemVindo,
    
    Perfil: Perfil,
    
    Notificacoes: Notificacoes,
    
    Planos: Planos,
    
    CriarEvento: CriarEvento,
    
    MeusEventos: MeusEventos,
    
    ComprarIngresso: ComprarIngresso,
    
    Configuracoes: Configuracoes,
    
    Comunidade: Comunidade,
    
    Chat: Chat,
    
    Feed: Feed,
    
    Documentacao: Documentacao,
    
    Descobrir: Descobrir,
    
    ListaEspera: ListaEspera,
    
    Onboarding: Onboarding,
    
    ConfiguracoesPrivacidade: ConfiguracoesPrivacidade,
    
    EditarEvento: EditarEvento,
    
    DashboardOrganizador: DashboardOrganizador,
    
    Recompensas: Recompensas,
    
    Ranking: Ranking,
    
    HistoricoPontos: HistoricoPontos,
    
    EventoAoVivo: EventoAoVivo,
    
    IntegracoesIngressos: IntegracoesIngressos,
    
    PerfilUsuario: PerfilUsuario,
    
    Recomendacoes: Recomendacoes,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Mapa />} />
                
                
                <Route path="/Mapa" element={<Mapa />} />
                
                <Route path="/BemVindo" element={<BemVindo />} />
                
                <Route path="/Perfil" element={<Perfil />} />
                
                <Route path="/Notificacoes" element={<Notificacoes />} />
                
                <Route path="/Planos" element={<Planos />} />
                
                <Route path="/CriarEvento" element={<CriarEvento />} />
                
                <Route path="/MeusEventos" element={<MeusEventos />} />
                
                <Route path="/ComprarIngresso" element={<ComprarIngresso />} />
                
                <Route path="/Configuracoes" element={<Configuracoes />} />
                
                <Route path="/Comunidade" element={<Comunidade />} />
                
                <Route path="/Chat" element={<Chat />} />
                
                <Route path="/Feed" element={<Feed />} />
                
                <Route path="/Documentacao" element={<Documentacao />} />
                
                <Route path="/Descobrir" element={<Descobrir />} />
                
                <Route path="/ListaEspera" element={<ListaEspera />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/ConfiguracoesPrivacidade" element={<ConfiguracoesPrivacidade />} />
                
                <Route path="/EditarEvento" element={<EditarEvento />} />
                
                <Route path="/DashboardOrganizador" element={<DashboardOrganizador />} />
                
                <Route path="/Recompensas" element={<Recompensas />} />
                
                <Route path="/Ranking" element={<Ranking />} />
                
                <Route path="/HistoricoPontos" element={<HistoricoPontos />} />
                
                <Route path="/EventoAoVivo" element={<EventoAoVivo />} />
                
                <Route path="/IntegracoesIngressos" element={<IntegracoesIngressos />} />
                
                <Route path="/PerfilUsuario" element={<PerfilUsuario />} />
                
                <Route path="/Recomendacoes" element={<Recomendacoes />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}